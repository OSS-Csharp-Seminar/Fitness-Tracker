﻿namespace Application.Common.Model
{
    internal class GlobalDeclaration
    {
        internal static readonly string _internalServerError = "Something went wrong.";
        internal static readonly string _successResponse = "Successful Response!";
    }
}
